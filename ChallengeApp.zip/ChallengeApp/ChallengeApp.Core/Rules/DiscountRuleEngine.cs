﻿using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Models;
using System.Collections.Generic;

namespace ChallengeApp.Core.Rules
{
    public class DiscountRuleEngine : IDiscountRuleEngine
    {
        private List<IDiscountRule> _rules = new List<IDiscountRule>();


        public DiscountRuleEngine(IEnumerable<IDiscountRule> rules)
        {
            _rules.AddRange(rules);
        }

        public decimal CalculateTotalDiscount(Applicant applicant, decimal cost)
        {
            decimal discount = 0;
            foreach (IDiscountRule rule in _rules)
            {
                if (rule.IsValid(applicant))
                    discount = rule.CalculateDiscount(applicant, cost);
            }
            return discount;
        }

    }

}
