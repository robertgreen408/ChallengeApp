﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Rules
{
    public abstract class ParameterizedRule : ApplicantRule
    {
        IEnumerable<RuleParameter> _parameters;
        public ParameterizedRule(IRuleValidationService service, IRuleParameterService parameterService) : base(service)
        {
            _parameters = parameterService.GetParameters(this);
        }
        public override bool IsValid(Applicant applicant)
        {
            return base.IsValid(applicant);
        }
    } 
}
