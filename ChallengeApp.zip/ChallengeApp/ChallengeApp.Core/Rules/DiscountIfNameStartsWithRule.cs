﻿using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using ChallengeApp.Core.Services;
using System.Linq;

namespace ChallengeApp.Core.Rules
{
    public class DiscountIfNameStartsWithRule : ParameterizedRule, IDiscountRule
    {        
        private readonly char _startsWithValue;
        public DiscountIfNameStartsWithRule(IRuleValidationService service, IRuleParameterService parameterService) : base(service, parameterService)
        {
            string val = parameterService.GetParameters(this)
                .Where(c => c.Key.ToLower() == "startswithvalue").FirstOrDefault().Value.ToLower();
            _startsWithValue = val.ToCharArray()[0];
        }

        public decimal CalculateDiscount(Applicant applicant, decimal cost)
        {
            decimal discount = 0;
            if (applicant.LastName.ToLower().StartsWith(_startsWithValue))
                discount = cost * (decimal).10;
     
            return discount;
        }       
    }

}
