﻿using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;

namespace ChallengeApp.Core.Rules
{
    public abstract class ApplicantRule : IApplicantRule
    {
        private IRuleValidationService _service;
        public long Id { get; set; }
        public string Name { get; set; }
        public ApplicantRule (IRuleValidationService service)
        {
            _service = service;
            Name = this.GetType().ToString();
            Id = _service.GetId(this);
        }
        public virtual bool IsValid(Applicant applicant)
        {
            return _service.Validate(this, applicant);
        }
    }
}
