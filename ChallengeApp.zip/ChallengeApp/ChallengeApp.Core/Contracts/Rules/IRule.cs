﻿using ChallengeApp.Core.Models;

namespace ChallengeApp.Core.Contracts.Rules
{
    public interface IApplicantRule
    {
        long Id { get; set; }
        public string Name { get; set; }
        bool IsValid(Applicant applicant);
    }
}
