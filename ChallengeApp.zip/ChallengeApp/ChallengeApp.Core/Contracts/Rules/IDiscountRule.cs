﻿using ChallengeApp.Core.Models;
using System;

namespace ChallengeApp.Core.Contracts.Rules
{
    public interface IDiscountRule: IApplicantRule
    {
        Decimal CalculateDiscount(Applicant applicant, decimal cost); 
    }
}
