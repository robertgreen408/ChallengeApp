﻿using ChallengeApp.Core.Models;

namespace ChallengeApp.Core.Contracts.Rules
{
    public interface IDiscountRuleEngine
    {
        decimal CalculateTotalDiscount(Applicant applicant, decimal cost);
    }
}