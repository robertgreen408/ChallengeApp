﻿namespace ChallengeApp.Core.Contracts.Services
{
    public interface ISalaryService
    {
        decimal GetAnnualSalary(long employeeId);
    }
}