﻿namespace ChallengeApp.Core.Contracts.Services
{
    public interface IConfigurationReader
    {
        string GetConnectionString();
    }
}