﻿using ChallengeApp.Core.Models;
using ChallengeApp.Core.Rules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Contracts.Services
{
    public interface IRuleParameterService
    {
        IEnumerable<RuleParameter> GetParameters(ParameterizedRule parameterizedRule);
    }
}
