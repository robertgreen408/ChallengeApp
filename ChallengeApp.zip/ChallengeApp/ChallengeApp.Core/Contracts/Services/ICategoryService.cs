﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Models;
using System.Collections.Generic;

namespace ChallengeApp.Core.Contracts.Services
{
    public interface ICategoryService : IRepository<Category>
    {
        IEnumerable<Category> GetDependentCategories();
        Category GetEmployeeCategory();
    }
}