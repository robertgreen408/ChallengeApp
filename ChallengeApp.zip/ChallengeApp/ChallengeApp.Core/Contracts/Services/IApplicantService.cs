﻿using ChallengeApp.Core.Contracts.Extensions;
using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Contracts.Services
{
    public interface IApplicantService : IRepository<Applicant>
    {
        decimal GetEmployeeSalary(long employeeId);
        IEnumerable<Applicant> GetDependents(long employeeId);
        object GetEmployee(long employeeId);
        object GetAllEmployees();
    }
}
