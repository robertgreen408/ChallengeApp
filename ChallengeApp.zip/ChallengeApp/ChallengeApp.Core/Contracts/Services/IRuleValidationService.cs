﻿using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Models;
using ChallengeApp.Core.Rules;
using ChallengeApp.Core.Settings;
using System;
using System.Collections.Generic;

namespace ChallengeApp.Core.Contracts.Services
{
    public interface IRuleValidationService
    {
        bool Validate(IApplicantRule baseRule, Applicant applicant);
        long GetId(ApplicantRule rule);
    }

}
