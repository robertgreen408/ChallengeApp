﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace ChallengeApp.Core.Contracts.Repositories
{
    public interface IRepository<T>
    {
        T Get(long entityId);
        T Add(T entity);
        T Update(T entity);
        IEnumerable<T> GetAll();
        IEnumerable<T> Find(System.Func<T, bool> predicate);
    }
}
