﻿using ChallengeApp.Core.Models;
using System.Collections.Generic;

namespace ChallengeApp.Core.Contracts.Repositories
{
    public interface IApplicantRepository
    {
        IEnumerable<Applicant> GetDependents(long employeeId);
    }
}