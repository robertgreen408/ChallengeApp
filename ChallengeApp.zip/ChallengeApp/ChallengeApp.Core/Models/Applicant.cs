﻿using Dapper.Contrib.Extensions;

namespace ChallengeApp.Core.Models
{
    public class Applicant
    {
        [Key]
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public long? PrimaryApplicantId { get; set; }
        public long Type { get; set; }
    }    
}
