﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Models
{
    public class RuleParameter
    {
        public long Id { get; set; }
        public long RuleId { get; set; }
        public string Key { get; set; }
        public dynamic Value { get; set; }

    }
}
