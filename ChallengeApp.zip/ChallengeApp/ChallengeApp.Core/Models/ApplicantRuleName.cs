﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Models
{
    public class ApplicantRuleName
    {
        public long Id { get; set; }
        public string RuleName { get; set; }
        public bool IsEnabled { get; set; }
    }
}
