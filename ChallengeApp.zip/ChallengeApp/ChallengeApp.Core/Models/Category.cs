﻿namespace ChallengeApp.Core.Models
{
    public class Category
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public bool IsPrimary { get; set; }
    }
}
