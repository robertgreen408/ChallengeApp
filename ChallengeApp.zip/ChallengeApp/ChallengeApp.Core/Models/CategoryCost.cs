﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Models
{
    public class CategoryCost
    {
        public long Id { get; set; }
        public long CategoryId { get; set; }
        public decimal AnnualCost { get; set; }
    }
}
