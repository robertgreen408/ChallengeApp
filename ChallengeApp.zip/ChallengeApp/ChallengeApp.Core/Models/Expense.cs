﻿namespace ChallengeApp.Core.Models
{
    public class Expense
    {
        public long ApplicantId { get; set; }
        public decimal Cost { get; set; }
        public decimal Discount { get; set; }
    }
}
