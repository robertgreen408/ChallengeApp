﻿namespace ChallengeApp.Core.Dtos
{
    public class InsuredPersonDto
    {
        public long Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int? PrimaryEmployeeId { get; set; }
        public int Type { get; set; }
      }
}
