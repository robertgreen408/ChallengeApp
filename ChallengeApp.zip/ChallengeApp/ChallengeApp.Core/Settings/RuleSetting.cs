﻿namespace ChallengeApp.Core.Settings
{
    public class RuleSetting
    {
    }

}
