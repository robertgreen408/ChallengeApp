﻿namespace ChallengeApp.Core.Settings
{
    public class DiscountRuleEnableSetting
    {
        public long ValidationRuleId { get; set; }
        public long ApplicantTypeId { get; set; }
        public bool Enabled { get; set; }
    }

}
