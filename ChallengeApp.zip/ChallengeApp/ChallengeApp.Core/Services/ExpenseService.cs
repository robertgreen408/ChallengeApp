﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Services
{
    public class ExpenseService : IExpenseService
    {
        private IRepository<Applicant> _applicantRepo;
        private IRepository<CategoryCost> _costRepo;
        private IDiscountRuleEngine _ruleEngine;

        public ExpenseService(IRepository<Applicant> applicantRepo, IRepository<CategoryCost> costRepository, IDiscountRuleEngine ruleEngine)
        {
            _applicantRepo = applicantRepo;
            _costRepo = costRepository;
            _ruleEngine = ruleEngine;
        }
        public Expense GetExpense(long applicantId)
        {
            var applicant = _applicantRepo.Get(applicantId);
            var costModel = _costRepo.Get(applicant.Type);
            var discount = _ruleEngine.CalculateTotalDiscount(applicant, costModel.AnnualCost);
            return new Expense { ApplicantId = applicantId, Cost = costModel.AnnualCost, Discount = discount };
        }
    }
}
