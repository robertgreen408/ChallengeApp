﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using ChallengeApp.Core.Rules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Services
{
    public class RuleParameterService : IRuleParameterService
    {
        private IRepository<RuleParameter> _repo;

        public RuleParameterService(IRepository<RuleParameter> repository)
        {
            _repo = repository;
        }

        public IEnumerable<RuleParameter> GetParameters(ParameterizedRule parameterizedRule)
        {            
            return _repo.Find(x => x.Id == parameterizedRule.Id);
        }
        Expression<Func<RuleParameter, bool>> GetByName(string name)
        {
            return x => x.Key.ToLower() == name.ToLower();
        }
    }
}
