﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Services
{
    public class CategoryService : ICategoryService
    {
        private IEnumerable<Category> _avaliableCategories;
        private IRepository<Category> _repo;

        public CategoryService(IRepository<Category> repository)
        {
            _avaliableCategories = repository.GetAll();
            _repo = repository;
        }
        public Category GetEmployeeCategory()
        {
            return _avaliableCategories.Where(c => c.IsPrimary).FirstOrDefault();
        }
        public IEnumerable<Category> GetDependentCategories()
        {
            return _avaliableCategories.Where(c => !c.IsPrimary);
        }

        public Category Get(long entityId)
        {
            return _repo.Get(entityId);
        }

        public Category Add(Category entity)
        {
            return _repo.Add(entity);
        }

        public Category Update(Category entity)
        {
            return _repo.Update(entity);
        }

        public IEnumerable<Category> GetAll()
        {
            return _repo.GetAll();
        }

        public IEnumerable<Category> Find(System.Func<Category, bool> predicate)
        {
            return _repo.Find(predicate);
        }
    }
}
