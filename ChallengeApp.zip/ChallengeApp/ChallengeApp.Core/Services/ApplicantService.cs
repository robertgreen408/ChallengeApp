﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using DapperExtensions;
namespace ChallengeApp.Core.Services
{
    public class ApplicantService : IApplicantService
    {
        private IRepository<Applicant> _repo;
        private ICategoryService _catService;
        private ISalaryService _salaryService;

        public ApplicantService(IRepository<Applicant> repository, ICategoryService categoryService, ISalaryService salaryService)
        {
            _repo = repository;
            _catService = categoryService;
            _salaryService = salaryService;
        }
        public Applicant Add(Applicant entity)
        {
            return _repo.Add(entity);
        }

        public IEnumerable<Applicant> Find(Func<Applicant, bool> predicate)
        {
            return _repo.Find(predicate);
        }

        public Applicant Get(long entityId)
        {
            return _repo.Get(entityId);
        }

        public IEnumerable<Applicant> GetAll()
        {
            return _repo.GetAll();
        }

        public object GetAllEmployees()
        {
            //would like to be able to query.
            return _repo.GetAll().Where(c => c.PrimaryApplicantId == null);
        }

        public IEnumerable<Applicant> GetDependents(long primaryApplicantId)
        {
            var all = _repo.GetAll().Where(c=>c.PrimaryApplicantId == primaryApplicantId);          
            return all;
        }

        public object GetEmployee(long employeeId)
        {
            return _repo.Get(employeeId);
        }

        public decimal GetEmployeeSalary(long employeeId)
        {
            var employee = _repo.Get(employeeId);
            if (employee.Type == _catService.GetEmployeeCategory().Id)
                return _salaryService.GetAnnualSalary(employeeId);
            return 0;
        }

        public Applicant Update(Applicant entity)
        {
            return _repo.Update(entity);
        }
       
    }
}
