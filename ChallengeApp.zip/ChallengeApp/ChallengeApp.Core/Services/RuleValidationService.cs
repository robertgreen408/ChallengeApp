﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using ChallengeApp.Core.Rules;
using ChallengeApp.Core.Settings;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ChallengeApp.Core.Services
{
    public class RuleValidationService : IRuleValidationService
    {
        private IRepository<DiscountRuleEnableSetting> _settingRepo;
        private IRepository<ApplicantRuleName> _rulesRepo;
        private IEnumerable<DiscountRuleEnableSetting> _settings;
        private IEnumerable<ApplicantRuleName> _rules;
        private ILogger _log;

        public RuleValidationService(IRepository<DiscountRuleEnableSetting> settingsRepository, IRepository<ApplicantRuleName> rulesRepository, ILogger<RuleValidationService> logger)
        { 
            _settings = settingsRepository.GetAll();
            _rules = rulesRepository.GetAll();
            _settingRepo = settingsRepository;
            _rulesRepo = rulesRepository;
            _log = logger;

        }

        public long GetId(ApplicantRule rule)
        {
            string ruleName = rule.GetType().Name;
            var rules = _rules.Where(c => c.RuleName == ruleName);
            if (rules.Any())
                return rules.FirstOrDefault().Id;
            else
                return _rulesRepo.Add(new ApplicantRuleName() { RuleName = rule.Name }).Id;
        }

        public bool Validate(IApplicantRule baseRule, Applicant applicant)
        {
            try 
            { 
                 return _settings.Where(
                    c=>c.ValidationRuleId == baseRule.Id && 
                    c.ApplicantTypeId == applicant.Type
                    ).FirstOrDefault().Enabled == true;     
            }
            catch
            {
                _log.LogError($"No enable setting with validation rule {baseRule.Id} and applicant type {applicant.Type}");
                return false;
            }
        }
    }

}
