﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Core.Services
{
    public class SalaryService : ISalaryService
    {
        private IRepository<Applicant> _repo;
        private ICategoryService _service;

        public SalaryService(IRepository<Applicant> repository, ICategoryService categoryService)
        {
            _repo = repository;
            _service = categoryService;
        }
        public decimal GetAnnualSalary(long employeeId)
        {
            var employee = _repo.Get(employeeId);
            if (employee.Type != _service.GetEmployeeCategory().Id)
                throw new ArgumentException($"Id {employeeId} is not an employee");
            return 2000;
        }
    }
}
