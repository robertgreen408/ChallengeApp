﻿using ChallengeApp.Core.Contracts.Services;
using Microsoft.Extensions.Configuration;
namespace ChallengeApp.Core.Services
{
    public class ConfigurationReader : IConfigurationReader
    {
        private readonly IConfiguration _config;

        public ConfigurationReader(IConfiguration config)
        {
            _config = config;
        }
        public string GetConnectionString()
        {
            return _config.GetConnectionString("ChallengeAppDB");
        }
    }
}
