export interface Expense{
    employeeId: number;
    cost:number;
    discount: number;
}