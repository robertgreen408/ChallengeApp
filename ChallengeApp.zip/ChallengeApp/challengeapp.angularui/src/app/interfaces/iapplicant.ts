export interface IApplicant{
    firstName: string;
    middleName: string;
    id?: number;
    lastName: string;
    type: number;
    primaryEmployeeId?: number;
}