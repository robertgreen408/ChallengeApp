import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HideService {
  private _showEditor = new Subject<any>();
  constructor() { }
  addEvent() {
    this._showEditor.next();
  }

  get events$ () {
    return this._showEditor.asObservable();
  }
}
