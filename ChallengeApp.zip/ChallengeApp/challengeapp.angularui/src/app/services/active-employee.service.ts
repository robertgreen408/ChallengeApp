import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Employee } from '../models/employee';

@Injectable({
  providedIn: 'root'
})
export class ActiveEmployeeService {

  private subject = new Subject<Employee>();

  setEmployee(employee: Employee) {
      this.subject.next(employee);
  }

  getEmployee(): Observable<Employee> {
      return this.subject.asObservable();
  }

}
