import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Employee } from '../models/employee';
import { EmployeeService } from './employee.service';

@Injectable({
  providedIn: 'root'
})
export class ActiveEmployeesService {

  private subject = new Subject<Employee[]>();
  constructor(private personService: EmployeeService){
    this.personService.getEmployees().subscribe((data: Employee[]) => {
      this.subject.next(data)    
    });
  }
 
  setEmployees(employees: Employee[]) {
      this.subject.next(employees);
  }

  getEmployees(): Observable<Employee[]> {
      return this.subject.asObservable();
  }
}
