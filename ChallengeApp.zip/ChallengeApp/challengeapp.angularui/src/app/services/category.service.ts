import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from '../Enums/insuredType';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private Url = "https://localhost:44336/api/Category";
  
  constructor(private httpClient: HttpClient) {  }

  getCategories(): Observable<Category[]> {
    return this.httpClient.get<Category[]>(this.Url);
  }
}
