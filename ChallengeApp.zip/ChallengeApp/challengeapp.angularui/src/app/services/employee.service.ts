import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Applicant} from '../models/applicant';
import { Employee} from '../models/employee';
import { Dependent} from '../models/dependent';
import { map } from 'rxjs/operators'
import { IApplicant } from '../interfaces/iapplicant';
import { Expense } from '../interfaces/expense';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})

export class EmployeeService {
  private Url = "https://localhost:44336/api/";
  
  constructor(private httpClient: HttpClient) {

  }
  getEmployees(): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(this.Url.concat("Employee"));
  }
  postEmployee(person: Applicant): Observable<Applicant> {
    return this.httpClient.post<IApplicant>(this.Url, person, httpOptions);
  }
  getDependants(id?: number): Observable<Dependent[]> {
    return this.httpClient.get<Dependent[]>(this.Url.concat("Employee/Dependents/", String(id)));
  }
  getExpenses(id?: number): Observable<Expense> {
    return this.httpClient.get<Expense>(this.Url.concat("Expense/", String(id)));
  }
  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, body was: `, error.error);
    }
    // Return an observable with a user-facing error message.
    return throwError(
      'Something bad happened; please try again later.');
  }
}


@Injectable({
  providedIn: 'root'
})
export class PersonsServiceCache {
  //employee: Employee;
  constructor() { }

}

function catchError(arg0: (error: any) => Observable<never>): import("rxjs").OperatorFunction<unknown, Employee> {
  throw new Error('Function not implemented.');
}
