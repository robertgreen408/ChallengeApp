import { Testclass } from './testclass';

describe('Testclass', () => {
  it('should create an instance', () => {
    expect(new Testclass()).toBeTruthy();
  });
});
