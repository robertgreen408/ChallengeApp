
import {Applicant} from './applicant'
import {Dependent} from './dependent'
export class Employee extends Applicant {
    dependants: Array<Dependent> = []
 }