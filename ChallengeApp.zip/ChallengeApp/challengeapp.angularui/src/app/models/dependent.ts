import { Applicant } from "./applicant";

export class Dependent extends Applicant {

}