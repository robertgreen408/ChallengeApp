import { IApplicant } from "../interfaces/iapplicant";

export class Applicant implements IApplicant{
    firstName: string ="";
    middleName: string="";
    id?: number = undefined;
    lastName: string="";
    type: number = 0;
    primaryEmployeeId?: number= undefined;    
}



