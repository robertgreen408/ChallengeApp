import { IApplicant } from "../interfaces/iapplicant";

export class InsuredPerson {
    person: IApplicant;
    cost: number;
    discount: number;

   constructor(person: IApplicant, cost:number, discount: number) {
       this.person = person;
       this.cost = cost;
       this.discount = discount;
   }
}