import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeViewComponent } from './ui/employee-view/employee-view.component';
import { HeaderComponent } from './ui/header/header.component';
import { HomeComponent } from './ui/home/home.component';
import { MainEditorComponent } from './ui/main-editor/main-editor.component';
import { PersonEditorComponent } from './ui/person-editor/person-editor.component';

const routes: Routes = [
  { path: '', component: EmployeeViewComponent },
  { path: 'addDeps', component: MainEditorComponent },
  { path: 'detail', component: MainEditorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
