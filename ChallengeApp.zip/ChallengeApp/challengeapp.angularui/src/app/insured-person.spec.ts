import { InsuredPerson } from './insured-person';

describe('InsuredPerson', () => {
  it('should create an instance', () => {
    expect(new InsuredPerson()).toBeTruthy();
  });
});
