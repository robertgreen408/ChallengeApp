import { CdkDetailRowDirective } from './cdk-detail-row.directive';

describe('CdkDetailRowDirective', () => {
  it('should create an instance', () => {
    const directive = new CdkDetailRowDirective();
    expect(directive).toBeTruthy();
  });
});
