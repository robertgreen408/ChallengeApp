import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatTableModule} from '@angular/material/table';
import { MatFormFieldModule} from '@angular/material/form-field';
import { MatInputModule} from '@angular/material/input';
import { MatSelectModule} from '@angular/material/select';
import { MatSidenavModule} from '@angular/material/sidenav';
import { MatListModule} from '@angular/material/list';
import { MatButtonModule} from '@angular/material/button';

import { PersonEditorComponent } from './ui/person-editor/person-editor.component';
import { HeaderComponent } from './ui/header/header.component';
import { HomeComponent } from './ui/home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EmployeeViewComponent } from './ui/employee-view/employee-view.component';
import { CdkDetailRowDirective } from './cdk-detail-row.directive';
import { DependentViewComponent } from './ui/dependent-view/dependent-view.component';
import { MainEditorComponent } from './ui/main-editor/main-editor.component';
import { EmployeeListComponent } from './ui/employee-list/employee-list.component';


@NgModule({
  declarations: [
    AppComponent,
    PersonEditorComponent,
    HeaderComponent,
    HomeComponent,
    EmployeeViewComponent,
    CdkDetailRowDirective,
    DependentViewComponent,
    MainEditorComponent,
    EmployeeListComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    MatButtonModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSidenavModule,
    MatListModule,   
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
