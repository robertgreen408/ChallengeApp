import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from 'src/app/Enums/insuredType';
import { Employee } from 'src/app/models/employee';
import { CategoryService } from 'src/app/services/category.service';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee-view',
  templateUrl: './employee-view.component.html',
  styleUrls: ['./employee-view.component.css'],
})

export class EmployeeViewComponent implements OnInit {
  @Input() activeEmployee!: Employee;

  
  selectItems = Array<Category>();
  insuredType = Category;
  constructor(private router: Router,private service: EmployeeService, private categoryService: CategoryService) {
    this.resetActiveEmployee();
    this.activeEmployee = this.resetActiveEmployee();
  }

  ngOnInit(): void {
    this.categoryService.getCategories().subscribe((data: Category[])=>{
      this.selectItems = data;
    });
  }

  onSubmit(){
   // this.activeEmployee.person.type = Number(this.activeEmployee.person.type);
   // this.service.postEmployee(this.activeEmployee.person).subscribe((data=>{
   //   if ((data.id ?? 0) > 0)
   //   {
    //    this.resetActiveEmployee();
    //    this.router.navigateByUrl('addDeps');
    //  }
        
    //}))   
  }
  resetActiveEmployee(){
    return { id: undefined, firstName: "", middleName: "", lastName: "", type: 0, primaryEmployeeId: undefined,dependants: [],  cost: 0, discount: 0};
  }
}
