import { Component, OnInit } from '@angular/core';
import { HideService } from 'src/app/services/hide.service';

@Component({
  selector: 'app-main-editor',
  templateUrl: './main-editor.component.html',
  styleUrls: ['./main-editor.component.css']
})
export class MainEditorComponent implements OnInit {
  isHiddenEditor: boolean = false;
  constructor(private hideService: HideService) { }

  ngOnInit(): void {
    this.hideService.events$.subscribe((c=>{
      this.isHiddenEditor = !this.isHiddenEditor;
    }));
  }

}
