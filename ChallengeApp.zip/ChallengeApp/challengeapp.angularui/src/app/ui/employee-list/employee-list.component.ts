import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/models/employee';
import { HideService } from 'src/app/services/hide.service';
import { EmployeeService } from 'src/app/services/employee.service';
import { ActiveEmployeeService } from 'src/app/services/active-employee.service';
import { ActiveEmployeesService } from 'src/app/services/active-employees.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
 employees: Array<Employee>;
  constructor(private personService: EmployeeService, private hideService: HideService, private activeEmployeService: ActiveEmployeeService, private activeEmployeesService: ActiveEmployeesService) {
    this.employees = new Array<Employee>();
    activeEmployeesService.getEmployees().subscribe((data=>{
      data.forEach(element => {
        this.employees.push(element);
      });
    }));
   }

  ngOnInit(): void {  
  }
onRemove(e: Event){
debugger
}
OnSelect(e:Employee){  
this.activeEmployeService.setEmployee(e)
}
onAdd(){
  this.hideService.addEvent();
}

}
