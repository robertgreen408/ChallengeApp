import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject, Subscription } from 'rxjs';
import { Category } from 'src/app/Enums/insuredType';
import { Dependent } from 'src/app/models/dependent';
import { Employee } from 'src/app/models/employee';
import { InsuredPerson } from 'src/app/models/InsuredPerson';
import { ActiveEmployeeService } from 'src/app/services/active-employee.service';
import { EmployeeService } from 'src/app/services/employee.service';
import { PersonEditorComponent } from '../person-editor/person-editor.component';

@Component({
  selector: 'app-depenandant-view',
  templateUrl: './dependent-view.component.html',
  styleUrls: ['./dependent-view.component.css']
})
export class DependentViewComponent implements OnInit {
  displayedColumns: string[] = ['delete', 'firstName', 'middleName', 'lastName', 'type', 'cost', 'discount']
  insuredIndividuals = new Array<InsuredPerson>();
  activeEmployee: Employee;
  dataSource: BehaviorSubject<InsuredPerson[]> = new BehaviorSubject<InsuredPerson[]>(this.insuredIndividuals);
  subscription: Subscription;
  InsuredType = Category;
  totalCost = 1100.00;
  constructor(private personService: EmployeeService, private changeDetectorRefs: ChangeDetectorRef, private activeEmployeService: ActiveEmployeeService) {
    this.activeEmployee = new Employee();    
    this.subscription = this.activeEmployeService.getEmployee().subscribe(employee => {
      this.activeEmployee = employee;
      if (this.activeEmployee != null)
        this.activeEmployee.dependants = [];
      this.personService.getDependants(employee.id).subscribe((data => {
        data.forEach(element => {
          this.activeEmployee?.dependants.push(element);
        });
        this.addToGrid()
      }))     
    });

  }

  ngOnInit(): void {

  }
  addToGrid() {
    if (this.activeEmployee != null) {
      this.insuredIndividuals = new Array<InsuredPerson>();
      
      this.personService.getExpenses(this.activeEmployee.id).subscribe((data=>{
        
        var insuredPerson = new InsuredPerson(this.activeEmployee,data.cost, data.discount);
        this.insuredIndividuals.push(insuredPerson)
        this.dataSource.next(this.insuredIndividuals);
      }))
      this.activeEmployee.dependants.forEach(element => {
        this.personService.getExpenses(element.id).subscribe((data=>{
          var insuredPerson = new InsuredPerson(element,data.cost, data.discount);
          this.insuredIndividuals.push(insuredPerson)
          this.dataSource.next(this.insuredIndividuals);
        }))      
        this.dataSource.next(this.insuredIndividuals);
      });
    }
  }
  deleteDependent(row: InsuredPerson) { var a = row }
}
