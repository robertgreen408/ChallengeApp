import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person-editor',
  templateUrl: './person-editor.component.html',
  styleUrls: ['./person-editor.component.css']
})
export class PersonEditorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
