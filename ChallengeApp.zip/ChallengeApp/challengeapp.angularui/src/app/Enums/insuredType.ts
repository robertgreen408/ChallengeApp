export class Category{
constructor(id:number, name:string, isPrimary: boolean ){
    this.id = id;
    this.name = name;
    this.isPrimary = isPrimary
}
id: number;
name: string;
isPrimary: boolean;

}
