﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ChallengeApp.Core.Rules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;

namespace ChallengeApp.Core.Rules.Tests
{
    [TestClass()]
    public class DiscountIfNameStartsWithRuleTests
    {
        [TestMethod()]
        public void CalculateDiscountTest()
        {
            var mockValService = new Mock<IRuleValidationService>();
            var mockParamService = new Mock<IRuleParameterService>();
            mockParamService.Setup(c => c.GetParameters(It.IsAny<ParameterizedRule>())).Returns(GetParameters('a'));
            var rule = new DiscountIfNameStartsWithRule(mockValService.Object, mockParamService.Object);
            var applicant = new Applicant() { LastName = "albert", Id = 1, Type = 0 };

            var result = rule.CalculateDiscount(applicant, 100);
            Assert.AreEqual(result, 10);

            var vv = rule.IsValid(applicant);
        }



        private IEnumerable<RuleParameter> GetParameters(char value)
        {
            List<RuleParameter> parameters = new List<RuleParameter>();
            parameters.Add(new RuleParameter() {Id = 0, RuleId = 1, Key = "startswithvalue", Value = value });

            return parameters;
        }
    }
}