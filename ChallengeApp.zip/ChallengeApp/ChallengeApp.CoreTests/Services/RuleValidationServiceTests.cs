﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ChallengeApp.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Settings;
using ChallengeApp.Core.Rules;
using ChallengeApp.Core.Models;
using ChallengeApp.Core.Contracts.Rules;
using Microsoft.Extensions.Logging;
using ChallengeApp.Core.Contracts.Services;

namespace ChallengeApp.Core.Services.Tests
{
    [TestClass()]
    public class RuleValidationServiceTests
    {
        [TestMethod()]
        public void ValidateTest()
        {
            var settingsRepo = new Mock<IRepository<DiscountRuleEnableSetting>>();
            settingsRepo.Setup(c => c.GetAll()).Returns(SetupSettings);
            var mockRulesRepo = new Mock<IRepository<ApplicantRuleName>>();
            var mockRuleParameterService = new Mock<RuleParameterService>();
            var mockRule = new Mock<IDiscountRule>();
            var mockLogger = new Mock<ILogger<RuleValidationService>>();
            mockRule.Setup(c => c.Id).Returns(1);
            var ruleService = new RuleValidationService(settingsRepo.Object, mockRulesRepo.Object, mockLogger.Object);
            Applicant applicant = new Applicant() { Type = 1 };
            var a = ruleService.Validate(mockRule.Object, applicant);
            Applicant applicant1 = new Applicant() { Type = 2 };
            var b = ruleService.Validate(mockRule.Object, applicant1);
            Applicant applicant2 = new Applicant() { Type = 3 };
            var c = ruleService.Validate(mockRule.Object, applicant2);
        }

        private IEnumerable<DiscountRuleEnableSetting> SetupSettings()
        {
            List<DiscountRuleEnableSetting> settings = new List<DiscountRuleEnableSetting>();
            settings.Add(new DiscountRuleEnableSetting() { ApplicantTypeId = 1, Enabled = true, ValidationRuleId = 1 });
            settings.Add(new DiscountRuleEnableSetting() { ApplicantTypeId = 2, Enabled = false, ValidationRuleId = 1 });
            settings.Add(new DiscountRuleEnableSetting() { ApplicantTypeId = 3, Enabled = true, ValidationRuleId = 1 });
            return settings;
        }
    }
}