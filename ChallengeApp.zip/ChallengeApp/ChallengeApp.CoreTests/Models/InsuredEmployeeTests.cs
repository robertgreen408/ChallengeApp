﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChallengeApp.Core.Models.Tests
{
    [TestClass()]
    public class InsuredEmployeeTests
    {
        [TestMethod()]
        public void GetCostTest()
        {

        }
    }
}