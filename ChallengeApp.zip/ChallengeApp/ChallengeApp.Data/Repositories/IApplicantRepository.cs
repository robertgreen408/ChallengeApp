﻿using ChallengeApp.Core.Models;
using System.Collections.Generic;

namespace ChallengeApp.Data.Repositories
{
    public interface IApplicantRepository
    {
        IEnumerable<Applicant> GetDependents(long employeeId);
    }
}