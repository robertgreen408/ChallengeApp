﻿using ChallengeApp.Core.Contracts.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq.Expressions;
using Dapper.Contrib;
using Microsoft.Extensions.Logging;
using System.Linq;
using ChallengeApp.Core.Contracts.Services;
using Dapper.Contrib.Extensions;

namespace ChallengeApp.Data.Repositories
{
    public abstract class RepositoryBase<T> : IRepository<T> where T : class
    {
        internal readonly string _connection;
        internal readonly ILogger _logger;

        public RepositoryBase(IConfigurationReader configuration, ILogger logger)
        {
            _connection = configuration.GetConnectionString();
            _logger = logger;
        }
        public virtual T Add(T entity)
        {
            try {
            using (SqlConnection conn = new SqlConnection(_connection))
            {                
                conn.Open();
                conn.Insert(entity);
                _logger.LogDebug("Entity Inserted", entity);
                return entity;
            }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Adding {entity.GetType().Name}", ex);
                throw;
            }

        }

        public virtual IEnumerable<T> Find(Func<T, bool> predicate)
        {
            try { 
            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();
                var results = conn.GetAll<T>().Where(predicate);
                _logger.LogDebug("Entities returned", results.Count());
                return results;
            }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Finding {predicate.ToString()}", ex);
                throw;
            }
        
        }

        public virtual T Get(long Id)
        {
            try { 
            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();
                var result = conn.Get<T>(Id);
                _logger.LogDebug("returning entity", result);
                return result;
            }
            }
            catch(Exception ex)
            {
                _logger.LogError($"Error Finding {typeof(T).Name}", ex);
                throw;
            }
        }

        public virtual IEnumerable<T> GetAll()
        {
            try { 
            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();
                var results = conn.GetAll<T>();
                _logger.LogDebug("returning entity", results.Count());
                return results;
            }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error getting all {typeof(T).Name}", ex);
                throw;
            }
        }

        public virtual T Update(T entity)
        {
            try { 
            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();
                conn.Update<T>(entity);
                _logger.LogDebug("Updated entity", entity);
                return entity;
            }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error updating {typeof(T).Name}", ex);
                throw;
            }
        }
    }
}
