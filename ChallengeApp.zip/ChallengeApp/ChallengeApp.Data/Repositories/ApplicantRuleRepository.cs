﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Rules;
using DapperExtensions;
using Dapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ChallengeApp.Core.Models;

namespace ChallengeApp.Data.Repositories
{
    public class ApplicantRuleRepository : RepositoryBase<ApplicantRuleName>
    {
        public ApplicantRuleRepository(IConfigurationReader configuration, ILogger<ApplicantRuleRepository> logger) : base(configuration, logger)
        {
        }
        //public override IEnumerable<ApplicantRuleName> GetAll()
        //{
        //    using (SqlConnection conn = new SqlConnection(base._connection))
        //    {
        //        string sql = "select * from applicantRule";
        //        conn.Open();
        //        var results = conn.Query(sql).ToList();
          
        //    }
        //    return base.GetAll();
        //}
    }
}
