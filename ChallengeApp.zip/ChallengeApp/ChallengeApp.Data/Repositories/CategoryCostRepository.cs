﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace ChallengeApp.Data.Repositories
{
    public class CategoryCostRepository : RepositoryBase<CategoryCost>
    {
        public CategoryCostRepository(IConfigurationReader configuration, ILogger<CategoryCostRepository> logger) : base(configuration, logger)
        {
        }
        public override CategoryCost Get(long categoryId)
        {
            string sql = "Select id, categoryId, AnnualCost from categoryCosts where categoryId = @categoryId";
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@categoryId", categoryId, System.Data.DbType.Int32);
     
            
            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();
                var result = conn.Query<CategoryCost>(sql, parameters).FirstOrDefault();
                _logger.LogDebug("returning entity", result);
                return result;
            }
        }
    }
}
