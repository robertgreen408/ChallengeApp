﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.Extensions.Logging;

namespace ChallengeApp.Data.Repositories
{
    public class CategoryRepository : RepositoryBase<Category>
    {
        public CategoryRepository(IConfigurationReader configuration, ILogger<CategoryRepository> logger) : base(configuration, logger)
        {
        }
    }
}
