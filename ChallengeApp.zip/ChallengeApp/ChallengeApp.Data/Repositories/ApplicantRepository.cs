﻿using ChallengeApp.Core.Contracts.Extensions;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace ChallengeApp.Data.Repositories
{
    public class ApplicantRepository : RepositoryBase<Applicant>, IDependentsRepo, IApplicantRepository
    {
        public ApplicantRepository(IConfigurationReader configuration, ILogger<ApplicantRepository> logger) : base(configuration, logger)
        {

        }
        public IEnumerable<Applicant> GetDependents(long employeeId)
        {
            return new List<Applicant>();
        }
    }
}
