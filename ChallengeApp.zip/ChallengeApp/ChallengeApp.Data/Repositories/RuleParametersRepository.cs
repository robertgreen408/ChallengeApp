﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Data.Repositories
{
    public class RuleParametersRepository : RepositoryBase<RuleParameter>
    {
        public RuleParametersRepository(IConfigurationReader configuration, ILogger<RuleParametersRepository> logger) : base(configuration, logger)
        {
        }
    }
}
