﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Settings;
using Dapper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChallengeApp.Data.Repositories
{
    public class DiscountRuleEnableSettingRepository : RepositoryBase<DiscountRuleEnableSetting>
    {
        public DiscountRuleEnableSettingRepository(IConfigurationReader configuration, ILogger<DiscountRuleEnableSettingRepository> logger) : base(configuration, logger)
        {
        }
        public override IEnumerable<DiscountRuleEnableSetting> GetAll()
        {
            string sql = "select ValidationRuleId, ApplicantTypeId, Enabled from DiscountRuleEnableSettings";     


            using (SqlConnection conn = new SqlConnection(_connection))
            {
                conn.Open();
                var result = conn.Query<DiscountRuleEnableSetting>(sql);
                _logger.LogDebug("returning entity", result);
                return result;
            }
        }       
    }
}
