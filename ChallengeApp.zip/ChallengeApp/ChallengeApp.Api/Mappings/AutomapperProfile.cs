﻿using AutoMapper;
using ChallengeApp.Core.Dtos;
using ChallengeApp.Core.Models;

namespace ChallengeApp.Core.Mappings
{
    public class AutomapperProfile
    {
        public class AutoMapperProfile : Profile
        {
            public AutoMapperProfile()
            {
                CreateMap<InsuredPersonDto, Applicant>();
            }
        }
    }
}
