﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChallengeApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private IApplicantService _service;

        public EmployeeController(IApplicantService service)
        {
            _service = service;
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAllEmployees());
        }
        [HttpGet("employeeId")]
        public IActionResult Get(long employeeId)
        {
            return Ok(_service.GetEmployee(employeeId));
        }
        [HttpGet("dependents/{employeeId}")]
        public IActionResult GetDependents(long employeeId)
        {
            return Ok(_service.GetDependents(employeeId));
        }
        [HttpPost]
        public IActionResult Post(Applicant emplyee)
        {
            return Ok(_service.Add(emplyee));
        }

        [HttpGet("Salary/{employeeId}")]
        public IActionResult GetSalary(int employeeId)
        {
            return Ok(_service.GetEmployeeSalary(employeeId));
        }
    }
}
