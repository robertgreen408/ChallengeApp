﻿using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChallengeApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DependentsController : ControllerBase
    {
        private IApplicantService _service;

        public DependentsController(IApplicantService service)
        {
            _service = service;
        }
      
        [HttpGet("{dependentId}")]
        public IActionResult Get(long dependentId)
        {
            return Ok(_service.Get(dependentId));
        }

        [HttpPost]
        public IActionResult Post(Applicant dependant)
        {
            return Ok(_service.Add(dependant));
        }

    }
}
