﻿using ChallengeApp.Core.Contracts.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChallengeApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExpenseController : ControllerBase
    {
        private readonly IExpenseService _service;
       

        public ExpenseController(IExpenseService service)
        {
            _service = service;           
        }

        [HttpGet("{Id}")]
        public IActionResult Get(long Id)
        {
         
            return Ok(_service.GetExpense(Id));
        }
    }
}
