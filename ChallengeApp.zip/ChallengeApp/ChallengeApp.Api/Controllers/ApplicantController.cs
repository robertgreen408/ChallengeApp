﻿using AutoMapper;
using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChallengeApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {
        private IApplicantService _service;

        public ApplicantController(IApplicantService service)
        {
            _service = service;
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }
   

        [HttpPost]
        public IActionResult Post(Applicant person)
        {
            return Ok(_service.Add(person));
        }

        [HttpGet("Salary/{employeeId}")]
        public IActionResult GetSalary(int employeeId)
        {
            return Ok(_service.GetEmployeeSalary(employeeId));
        }
    }
    
}
