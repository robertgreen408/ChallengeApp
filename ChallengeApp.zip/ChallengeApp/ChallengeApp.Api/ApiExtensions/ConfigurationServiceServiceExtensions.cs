﻿using ChallengeApp.Core.Contracts.Repositories;
using ChallengeApp.Core.Contracts.Rules;
using ChallengeApp.Core.Contracts.Services;
using ChallengeApp.Core.Models;
using ChallengeApp.Core.Rules;
using ChallengeApp.Core.Services;
using ChallengeApp.Core.Settings;
using ChallengeApp.Data.Repositories;
using Microsoft.Extensions.Configuration;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ConfigurationServiceServiceExtensions
    {
        public static IServiceCollection AddDiscountRules(this IServiceCollection services, IConfiguration config)
        {
            services.AddScoped<IDiscountRule, DiscountIfNameStartsWithRule>();
            return services;
        }
        public static IServiceCollection AddServices(this IServiceCollection services, IConfiguration config)
        {
            services.AddScoped<IConfigurationReader, ConfigurationReader>();
            services.AddScoped<IRuleValidationService, RuleValidationService>();
            services.AddScoped<IRuleParameterService, RuleParameterService>();
            services.AddScoped<IExpenseService, ExpenseService>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<IDiscountRuleEngine, DiscountRuleEngine>();
            services.AddScoped<ISalaryService, SalaryService>();
            services.AddScoped<IApplicantService, ApplicantService>();
            return services;
        }
        public static IServiceCollection AddRepositories(this IServiceCollection services, IConfiguration config)
        {
            services.AddScoped(typeof(IRepository<RuleParameter>), typeof(RuleParametersRepository));           
            services.AddScoped(typeof(IRepository<Category>), typeof(CategoryRepository));
            services.AddScoped(typeof(IRepository<Applicant>), typeof(ApplicantRepository));
            services.AddScoped(typeof(IRepository<ApplicantRuleName>), typeof(ApplicantRuleRepository));
            services.AddScoped(typeof(IRepository<CategoryCost>), typeof(CategoryCostRepository));
            services.AddScoped(typeof(IRepository<DiscountRuleEnableSetting>), typeof(DiscountRuleEnableSettingRepository));
            return services;
        }
    }
}
