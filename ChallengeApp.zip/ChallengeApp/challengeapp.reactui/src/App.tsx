import React, {useEffect, useState} from 'react';
import logo from './logo.svg';
import './App.css';
import NavBar from './ui/nav'
import UserTable from './ui/table'
import Title  from './ui/test'

function App() {
  const [employees, setAllEmployees] = useState([])
  useEffect(()=>{
    const fetchEmployees = async () => {
      const rsp = await fetch ('./data.json');
      const employees = await rsp.json();
      debugger;
      setAllEmployees(employees);
    };
    fetchEmployees();
  }, []);
  return (
    
    <div>
      <div>
      <NavBar></NavBar>
    </div>
   
    <div>
        <UserTable></UserTable>
    </div>
    </div>


   
  );
}

export default App;
