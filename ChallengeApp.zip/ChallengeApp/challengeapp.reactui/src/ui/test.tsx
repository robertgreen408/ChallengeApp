import { count } from 'console';
import React, { Component } from 'react';
import ReactDOM from 'react-dom';

interface TitleProps {
  title: string;
  subtitle?: string;
}

class Title extends React.Component<TitleProps> {
  props = {title: 'Hello', subtitle: 'google'}  
  render() {
    
    return (
      <>
        <h1>{this.props.title}</h1>
        <h2>{this.props.subtitle}</h2>       
      </>
    );
  }
}
export default Title;   

